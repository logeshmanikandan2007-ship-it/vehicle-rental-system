<?php
include 'db.php';
if(isset($_POST['register']))
{
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $password = $_POST['password'];

    $sql = "INSERT INTO users(name,email,phone,password)
            VALUES('$name','$email','$phone','$password')";

    mysqli_query($conn, $sql);

    echo "<script>alert('Registration Successful');</script>";
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>User Registration</title>
</head>
<body>

    <h2>User Registration</h2>

    <form method="post">
        <label>Full Name:</label><br>
        <input type="text" name="name"><br><br>

        <label>Email:</label><br>
        <input type="email" name="email"><br><br>

        <label>Phone Number:</label><br>
        <input type="text" name="phone"><br><br>

        <label>Password:</label><br>
        <input type="password" name="password"><br><br>

        <input type="submit" name="register" value="Register">
    </form>

    <br>

    <a href="index.php">⬅️ Back to Home</a>

</body>
</html>
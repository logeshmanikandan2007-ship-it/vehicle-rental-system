<?php
include 'db.php';

if(isset($_POST['book']))
{
    $user_name = $_POST['user_name'];
    $vehicle_name = $_POST['vehicle_name'];
    $booking_date = $_POST['booking_date'];
    $status = "Booked";

    $sql = "INSERT INTO bookings(user_name, vehicle_name, booking_date, status)
            VALUES('$user_name','$vehicle_name','$booking_date','$status')";

    if(mysqli_query($conn,$sql))
    {
        echo "<script>alert('Vehicle Booked Successfully');</script>";
    }
    else
    {
        echo "<script>alert('Booking Failed');</script>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Book Vehicle</title>

    <style>
        body{
            margin:0;
            padding:0;
            font-family:Arial,sans-serif;
            background:#f2f2f2;
        }

        .container{
            width:450px;
            margin:50px auto;
            background:white;
            padding:30px;
            border-radius:15px;
            box-shadow:0 0 15px rgba(0,0,0,0.2);
        }

        h2{
            text-align:center;
            color:#007bff;
        }

        label{
            font-weight:bold;
        }

        input{
            width:100%;
            padding:10px;
            margin-top:5px;
            margin-bottom:15px;
            border:1px solid #ccc;
            border-radius:5px;
            box-sizing:border-box;
        }

        input[type=submit]{
            background:#28a745;
            color:white;
            border:none;
            cursor:pointer;
            font-size:16px;
        }

        input[type=submit]:hover{
            background:#218838;
        }

        .back{
            display:block;
            text-align:center;
            margin-top:20px;
            text-decoration:none;
            color:#007bff;
            font-weight:bold;
        }

        .back:hover{
            text-decoration:underline;
        }
    </style>

</head>

<body>

<div class="container">

<h2>🚗 Vehicle Booking</h2>

<form method="post">

<label>User Name</label>
<input type="text" name="user_name" required>

<label>Vehicle Name</label>
<input type="text" name="vehicle_name" required>

<label>Booking Date</label>
<input type="date" name="booking_date" required>

<input type="submit" name="book" value="Book Vehicle">

</form>

<a class="back" href="index.php">⬅ Back to Home</a>

</div>

</body>
</html>
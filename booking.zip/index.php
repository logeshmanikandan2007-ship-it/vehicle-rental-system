<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Vehicle Rental System</title>

    <style>
        body{
            margin:0;
            padding:0;
            font-family:Arial,sans-serif;
            background:linear-gradient(135deg,#4facfe,#00f2fe);
        }

        .container{
            width:500px;
            margin:50px auto;
            background:#fff;
            padding:30px;
            border-radius:15px;
            box-shadow:0 0 20px rgba(0,0,0,0.3);
            text-align:center;
        }

        h1{
            color:#007bff;
            margin-bottom:10px;
        }

        h2{
            color:#333;
        }

        p{
            color:#555;
            font-size:16px;
        }

        hr{
            margin:20px 0;
        }

        a{
            display:block;
            width:250px;
            margin:12px auto;
            padding:12px;
            background:#007bff;
            color:white;
            text-decoration:none;
            border-radius:8px;
            font-weight:bold;
            transition:0.3s;
        }

        a:hover{
            background:#0056b3;
            transform:scale(1.05);
        }
    </style>
</head>

<body>

<div class="container">

<h1>🚗 Vehicle Rental System</h1>

<h2>
Welcome,
<?php
if(isset($_SESSION['user_name']))
{
    echo $_SESSION['user_name'];
}
else
{
    echo "Guest";
}
?>
</h2>

<p>Rent Cars and Bikes Easily.</p>

<hr>

<a href="register.php">👤 User Register</a>

<a href="login.php">🔑 User Login</a>

<a href="vehicles.php">🚗 Available Vehicles</a>

<a href="booking.php">📅 Book Vehicle</a>

<a href="booking_history.php">📖 My Bookings</a>

<a href="logout.php">🚪 Logout</a>

<a href="admin.php">👨‍💼 Admin Panel</a>

</div>

</body>
</html>
<?php
include 'db.php';

$sql = "SELECT * FROM bookings";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>My Bookings</title>

    <style>
        body{
            margin:0;
            padding:0;
            font-family:Arial,sans-serif;
            background:#f2f2f2;
        }

        .container{
            width:90%;
            margin:40px auto;
            background:#fff;
            padding:20px;
            border-radius:15px;
            box-shadow:0 0 15px rgba(0,0,0,0.2);
        }

        h2{
            text-align:center;
            color:#007bff;
        }

        table{
            width:100%;
            border-collapse:collapse;
            margin-top:20px;
        }

        th{
            background:#007bff;
            color:white;
        }

        th,td{
            border:1px solid #ddd;
            padding:12px;
            text-align:center;
        }

        tr:nth-child(even){
            background:#f9f9f9;
        }

        tr:hover{
            background:#eaf4ff;
        }

        .cancel{
            background:red;
            color:white;
            padding:6px 12px;
            text-decoration:none;
            border-radius:5px;
        }

        .cancel:hover{
            background:darkred;
        }

        .back{
            display:inline-block;
            margin-top:20px;
            padding:10px 20px;
            background:#28a745;
            color:white;
            text-decoration:none;
            border-radius:5px;
        }

        .back:hover{
            background:#218838;
        }
    </style>
</head>

<body>

<div class="container">

<h2>📖 My Bookings</h2>

<table>

<tr>
    <th>ID</th>
    <th>User Name</th>
    <th>Vehicle Name</th>
    <th>Booking Date</th>
    <th>Status</th>
    <th>Action</th>
</tr>

<?php
while($row=mysqli_fetch_assoc($result))
{
?>

<tr>
    <td><?php echo $row['id']; ?></td>
    <td><?php echo $row['user_name']; ?></td>
    <td><?php echo $row['vehicle_name']; ?></td>
    <td><?php echo $row['booking_date']; ?></td>
    <td><?php echo $row['status']; ?></td>
    <td>
        <a class="cancel" href="cancel_booking.php?id=<?php echo $row['id']; ?>" onclick="return confirm('Are you sure you want to cancel this booking?');">
            Cancel
        </a>
    </td>
</tr>

<?php
}
?>

</table>

<br>

<a class="back" href="index.php">⬅ Back to Home</a>

</div>

</body>
</html>
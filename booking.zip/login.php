<?php
session_start();
include 'db.php';

if(isset($_POST['login']))
{
    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM users WHERE email='$email' AND password='$password'";
    $result = mysqli_query($conn, $sql);

    if(mysqli_num_rows($result) > 0)
    {
        $row = mysqli_fetch_assoc($result);

        $_SESSION['user_name'] = $row['name'];

        header("Location: index.php");
        exit();
    }
    else
    {
        echo "<script>alert('Invalid Email or Password');</script>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>User Login</title>

    <style>
        body{
            font-family: Arial;
            background:#f2f2f2;
        }

        .container{
            width:400px;
            margin:80px auto;
            background:white;
            padding:20px;
            border-radius:10px;
            box-shadow:0 0 10px gray;
        }

        input{
            width:100%;
            padding:10px;
            margin:8px 0;
            box-sizing:border-box;
        }

        input[type=submit]{
            background:green;
            color:white;
            border:none;
            cursor:pointer;
        }

        input[type=submit]:hover{
            background:darkgreen;
        }

        a{
            text-decoration:none;
        }
    </style>
</head>

<body>

<div class="container">

<h2>User Login</h2>

<form method="post">

<label>Email:</label><br>
<input type="email" name="email" required><br><br>

<label>Password:</label><br>
<input type="password" name="password" required><br><br>

<input type="submit" name="login" value="Login">

</form>

<br>

<a href="index.php">⬅ Back to Home</a>

</div>

</body>
</html>
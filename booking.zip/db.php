<?php
$conn = mysqli_connect("localhost","root","","vehicle_rental");

if(!$conn){
    die("Database Connection Failed");
}
?>
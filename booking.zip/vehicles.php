<?php
include 'db.php';

$sql = "SELECT * FROM vehicles";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Available Vehicles</title>

    <style>
        body{
            font-family:Arial,sans-serif;
            background:#f2f2f2;
        }

        .container{
            width:90%;
            margin:30px auto;
            background:white;
            padding:20px;
            border-radius:10px;
            box-shadow:0 0 10px gray;
        }

        h2{
            text-align:center;
            color:#007bff;
        }

        table{
            width:100%;
            border-collapse:collapse;
        }

        th,td{
            border:1px solid #ddd;
            padding:10px;
            text-align:center;
        }

        th{
            background:#007bff;
            color:white;
        }

        img{
            width:120px;
            height:80px;
            border-radius:5px;
        }

        a{
            text-decoration:none;
            color:blue;
        }
    </style>
</head>

<body>

<div class="container">

<h2>🚗 Available Vehicles</h2>

<table>

<tr>
    <th>Image</th>
    <th>ID</th>
    <th>Vehicle Name</th>
    <th>Vehicle Type</th>
    <th>Rent Per Day</th>
    <th>Status</th>
</tr>

<?php
while($row=mysqli_fetch_assoc($result))
{
?>

<tr>

<td>
<img src="images/<?php echo $row['image']; ?>">
</td>

<td><?php echo $row['id']; ?></td>

<td><?php echo $row['vehicle_name']; ?></td>

<td><?php echo $row['vehicle_type']; ?></td>

<td>₹<?php echo $row['rent_per_day']; ?></td>

<td><?php echo $row['status']; ?></td>

</tr>

<?php
}
?>

</table>

<br>

<a href="index.php">⬅ Back to Home</a>

</div>

</body>
</html>